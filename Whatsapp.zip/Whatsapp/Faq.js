var app = angular.module('whatsApp',[]);
app.controller('faqCtrl',function($scope){
	
});